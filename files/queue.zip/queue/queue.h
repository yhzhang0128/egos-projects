/* Do not modify this file.
 * But read this file carefully.
 * See the README for instructions.
 */

/*
 * queue_t is a pointer to an internally maintained data structure.
 * Clients of this package do not need to know how queues are
 * represented. They see and manipulate only queue_t's.
 */
typedef struct queue *queue_t;

/*
 * Return an empty queue. 
 * Return NULL on error (e.g., malloc() failed).
 */
queue_t queue_new();

/*
 * Enqueue an item.
 * Return 0 (success) or -1 (failure).  
 * A reason for failure may be no enough memory left.
 */
int queue_enqueue(queue_t queue, void* item);

/*
 * Prepend an item to the beginning of the queue.
 * This item should be returned first on dequeue.
 * Return 0 (success) or -1 (failure).
 * A reason for failure may be no enough memory left.
 */
int queue_insert(queue_t queue, void* item);

/*
 * Dequeue and return the first item from the queue.
 * If pitem == NULL, then dequeue without returning the item.
 * If pitem != NULL, then dequeue and return the item by
 *   `*pitem = {item from queue}`
 * Make sure you understand which piece of memory is modified
 * when executing `*pitem = {item from queue}`.
 * Return 0 (success) if queue is nonempty.
 * Return -1 (failure) if queue is empty.
 */
int queue_dequeue(queue_t queue, void** pitem);

/*
 * Call f(item, context) for each item in queue.
 */
typedef void (*queue_func_t)(void* item, void* context);
void queue_iterate(const queue_t queue, queue_func_t f, void* context);

/*
 * Free the queue only if the queue is empty.
 * If the queue is non-empty, do not modify anything.
 * Return 0 (success) or -1 (failure) if queue is non-empty.
 */
int queue_free(queue_t queue);

/*
 * Return the number of items in the queue.
 */
int queue_length(const queue_t queue);

/*
 * Delete the first instance (the first to be dequeued) of 
 * the specified item from the given queue.
 * Return 0 if an item is deleted, or -1 otherwise (item not found).
 */
int queue_delete(queue_t queue, void* item);
