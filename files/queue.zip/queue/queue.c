/* You will handin this file.
 * See the README for instructions.
 */

#include "queue.h"
#include <stdlib.h>
#include <stdio.h>

typedef struct queue {
    // your code here
} *queue_t;

queue_t queue_new() {
    // your code here
}

int queue_enqueue(queue_t queue, void* item) {
    // your code here
}

int queue_insert(queue_t queue, void* item) {
    // your code here
}

int queue_dequeue(queue_t queue, void** pitem) {
    // your code here
}

void queue_iterate(const queue_t queue, queue_func_t f, void* context) {
    // your code here
}

int queue_free(queue_t queue) {
    // your code here
}

int queue_length(const queue_t queue) {
    // your code here
}

int queue_delete(queue_t queue, void* item) {
    // your code here
}
